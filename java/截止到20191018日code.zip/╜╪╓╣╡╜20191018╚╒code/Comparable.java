
public interface Comparable {
	//接口类中只包含抽象方法。
	public int comparTo(Object o);
}
