
public class Dog extends Animal implements Comparable {
	
	public void shout(){
		System.out.println("Dog shout!");
	}
	
	public int comparTo(Object o){
		//to do something
		return 0;
	}

}
