package Class0910;

import java.util.Scanner;

public class First {
    public static void main(String[] args){
//        Scanner scan=new Scanner(System.in);
//        int a=scan.nextInt();
//        float b=scan.nextFloat();
//        String str=scan.next();
//        System.out.println(a+"  "+b+"   "+str);
        /*
        基本类型：
            -整数类型 byte,short,int,long
            -浮点数 double，float
            -字符类型 char
            -布尔类型 boolean
        引用数据类型：
            -类、接口、数组、枚举
        * */

    }
}
