package Class0910;

public class Second {
    public static void main(String[] argv)
    {
        System.out.println("11323");
    }
}
