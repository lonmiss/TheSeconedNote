//package homeWork;
//
//import java.util.Arrays;
//
//public class Xuelizuoye1_3_1 {
//    public class Students{
//        String id;
//        String name;
//        int score;
//    }
//    static public void main(String[] args){
//        String[] stuNo = { "2019011535", "2019011534", "2019011539", "2019011538", "2019011537" };
//        String[] stuName = { "张三", "李四", "王五", "赵六", "王九" };
//        int[] stuScore = { 53, 78, 96, 66, 85 };
//        Students[] arr=new Students[5];
//        for (int i = 0; i < stuNo.length; i++) {
//            replaceAll(stuNo[i],arr[i].id);
//            System.out.println(arr[i].id);
//        }
//    }
//}
