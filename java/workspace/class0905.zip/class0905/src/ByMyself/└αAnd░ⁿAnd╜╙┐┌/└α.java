package ByMyself.类And包And接口;

public class 类 {

}
