//package ByMyself;
//
//import java.util.Random;
//
//public class first1 {
//    //public static void main(String[] args)
//    {
//        //Random rand=new Random(2);
//        //System.out.println("123456~");
//        //java 数组
//
//        //Foreach语法
////        Random rand = new Random(47);
////        float f[]=new float[10];
////        for(int i=0;i<10;i++)
////        {
////            f[i]=rand.nextFloat();
////        }
////        for(float x:f)//定义一个float类型的变量x,将每一个f的元素赋值给x
////        {
////            System.out.println(x);
////        }
//
////        Random rand=new Random(2);
////        int f1[]=new int[10];
////        for(int i=0;i<10;i++)
////        {
////            f1[i]=rand.nextInt();
////            System.out.println(f1[i]);
////        }
////        System.out.println("########");
////        for(int x:f1)
////        {
////            System.out.println(x);
////        }
//
//        /*
//            为了简化这些任务，我们在net.mindview.util.Range
//            包中创建了一个range（）的方法，它可以自动生成恰当的数组
//            目的是：将range（）用作static导入
//        * */
//        for (int i:range(5,10)//5~9
//             ) {
//            System.out.print(i+" ");
//        }
//    }
//
//}