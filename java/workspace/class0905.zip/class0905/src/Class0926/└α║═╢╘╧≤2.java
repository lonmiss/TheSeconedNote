package Class0926;

public class 类和对象2 {
    //1

    public static void main(String[] args)
    {

    }
}
