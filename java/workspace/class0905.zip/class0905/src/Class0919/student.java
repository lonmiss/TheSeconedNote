package Class0919;

public class student {
    public int age;
    public String name;
}
