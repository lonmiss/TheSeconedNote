package Class0919;

import java.util.Arrays;
import java.util.Scanner;

public class Demo1 {
    static public void main(String[] args){
        student s1=new student();
        s1.age=18;

    }
}

//        System.out.println("666666");
//        int[] a=new int[2];
//        int[] b=new int[2];
//        Scanner in=new Scanner(System.in);
//
//        System.out.println(Arrays.equals(a,b));